<!-- models -->

<?php  

defined('BASEPATH') OR exit('No direct script access allowed');


/**
 * summary
 */
class Db_data extends CI_Model
{

    // retrieving data
    public function getdata()
    {
    	$table = $this->db->table_exists('account');
        if ($table) {
            $query = $this->db->get('account');
            if ($query->num_rows() > 0) {
                //if the number of data inside the table account is more than 0 
                // 
                return $query->result();
            }
            else{
                //if no data inside the table account 
                //
                return false;
            }
        }
        else{
            return false;
        }
    }
    // end of retrieving data


    // Inserting
    public function signup()
    {

        $pass = $this->input->post('password');
        $fname = $this->input->post('fname');
        $lname = $this->input->post('lname');
        $email = $this->input->post('email');
        $hash = password_hash($pass, PASSWORD_BCRYPT);
        $bal = 0.0;
       
        // standard inserting
        $sql = "INSERT INTO account(fname,lname,email,password,balance) VALUES ('$fname','$lname','$email','$hash','$bal')";

        if ($this->db->query($sql)) {
            if ($this->db->affected_rows() > 0) {
                return true;
            }
            else{
                return false;
            }
        }
        else {
            return false;
        }
    }

    // end of inserting

    public function user_login(){
        $email = $this->input->post('email');
        $pass = $this->input->post('pass');

        $query = "SELECT *FROM account WHERE email='$email'";
        if ($this->db->query($query)) {
            foreach ($query->result as $row) {
                $hash = $row->password;
                if (password_verify($pass, $hash)) {
                    return true;
                }
            }
        }
        else{
            return false;
        }

    }
// Update
    public function getid($id){
        $this->db->where('id',$id);
        $query = $this->db->get('account');
        if ($query->num_rows() > 0) {
            return $query->row();
        }
        else {
            return false;
        }
    }


    public function update()
    {
        $id = $this->input->post('id');
        $fname = $this->input->post('fname');
        $lname = $this->input->post('lname');
        $email = $this->input->post('email');

        // standard Update
        $query = "UPDATE account SET fname ='$fname',lname='$lname',email='$email' WHERE id = $id";
        if ($this->db->query($query)) {
            if ($this->db->affected_rows() > 0) {
                return true;
            }
            else{
                return false;
            }
        }
    }
// end of update

    // delete

    public function delete_data($id)
    {
        $this->db->where('id',$id);
        $this->db->delete('account');
        if ($this->db->affected_rows() > 0) {
            return true;
        }
        else {
            return false;
        }
    }


    // end of delete

}


?>