<!-- View -->

<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title></title>
	<link rel="stylesheet" href="<?php echo base_url('assets/css/style.css'); ?>">
	<link rel="preconnect" href="https://fonts.gstatic.com">
	<script src="<?php echo base_url('assets/js/fontawesome.js') ?>" type="text/javascript"></script>
	<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300&display=swap" rel="stylesheet">
	<link rel="preconnect" href="https://fonts.gstatic.com">
	<link href="https://fonts.googleapis.com/css2?family=Roboto&display=swap" rel="stylesheet">
	<link rel="preconnect" href="https://fonts.gstatic.com">
<link href="https://fonts.googleapis.com/css2?family=Lato:wght@700&family=Roboto&display=swap" rel="stylesheet">
</head>
<body>

<!-- header -->
	<header>
		<div class="head">
			
			<a href="<?php echo base_url('sample/index') ?>">Web Application</a>
		</div>
		<div class="log">
			<ul>
				<!-- <li><a id="login" title="Login">Login</a></li> -->
				<li><a id="signup" title="Add Data">Add Data</a></li>
			</ul>
		</div>
	</header>
<!-- end of header -->

<!-- section -->
	<section>
		<div class="content">
			<!-- <a href="edit">Edit</a> -->
		</div>
	</section>
<!-- end of section -->

<!-- data -->
	<table border="1" width="100%">
		<tr>
			<th colspan="7">Data</th>
		</tr>
		<tr>
			<th>ID</th>
			<th>Fname</th>
			<th>Lname</th>
			<th>Email</th>
			<th>Edit</th>
			<th>Delete</th>
			<!-- <th>Balance</th> -->
		</tr>
		<?php 
			
			if ($datas) {
				foreach ($datas as $data) {
				    ?>
				    <tr align="center">
				    	<td><?php echo $data->id; ?></td>
				    	<td><?php echo $data->fname; ?></td>
				    	<td><?php echo $data->lname; ?></td>
				    	<td><?php echo $data->email; ?></td>
				    	
				    	<td><a href="<?php echo base_url('sample/edit/' .$data->id); ?>" id="edit">Edit</a></td>
				    	<td><a href="<?php echo base_url('sample/delete/' .$data->id); ?>" id="delete" onclick="return confirm('Do you want to Delete this?')">Delete</a></td>
				    </tr>
				    <?php
				}
			}
		?>
	</table>
<!-- end of data -->

<!-- signup -->
	<div class="sign">
		<div class="sign_content">
			<form action="<?php echo base_url('sample/sign') ?>" method="POST" autocomplete="off">
				<center><span>Create Account</span></center>
				<label for="fname">
					First Name:
				</label>
				<input id="fname" type="text" name="fname" placeholder="First Name"  value="" required>
				<label for="fname">
					Last Name:
				</label>
				<input id="lname" type="text" name="lname" placeholder="Last Name"  value="" required>
				<label for="fname">
					Email:
				</label>
				<input id="user" type="text" name="email" placeholder="Email"  value="" required>
				<label for="fname">
					Password
				</label>
				<input id="pass" type="password" name="password" placeholder="Password"  value="" required>
				<button type="submit" name="register">Register</button>
			</form>
			<img id='close' title='Exit' src="<?php echo base_url('assets/svg/times-solid.svg') ?>" alt='' width='13px'>
		</div>
	</div>
<!-- end of signup -->

<!-- login -->

	<div class="login">
		<div class="login_content">
			<form action="<?php echo base_url('sample/login'); ?>" autocomplete="off" method="POST">
				<center><span>Login</span></center>
				<label for="username">
					Username: 
				</label>
				<input id="user" type="text" name="email" placeholder="Username" >
				<label for="pass">
					Password:
				</label>
				<input id="pass" type="password" name="pass" placeholder="Password" >
				<button type="submit" name="login">Login</button>
			</form>
			<img id='close1' title='Exit' src="<?php echo base_url('assets/svg/times-solid.svg') ?>" alt='' width='13px'>
		</div>
	</div>
<!-- end of login -->
	

<script src="<?php echo base_url('assets/js/function.js') ?>" type="text/javascript"></script>

<script type="text/javascript">

	var sign = document.querySelector(".sign");
	var fname = document.getElementById('fname');
	var lname = document.getElementById('lname');
	var user = document.getElementById('user');
	var pass = document.getElementById('pass');
	var log = document.querySelector(".login");


	//handler
	document.addEventListener('keyup',signup_exit,false);
	document.addEventListener('keyup',log_exit,false);


	function signup_exit(btn) {
		if (btn.charCode == 27 || btn.keyCode == 27) {
			sign.classList.remove('bg-active');
			fname.value="";
			lname.value="";
			user.value="";
			pass.value="";
		}
	}

	function log_exit(btn){
		if (btn.charCode == 27 || btn.keyCode == 27) {
			log.classList.remove('bg-active');
			user.value="";
			pass.value="";
		}
	}

</script>

</body>
</html>


