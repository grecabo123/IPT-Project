<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title>Edit</title>
	<link rel="stylesheet" href="<?php echo base_url('assets/css/edit.css'); ?>">
	<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300&display=swap" rel="stylesheet">
	<link rel="preconnect" href="https://fonts.gstatic.com">
	<link href="https://fonts.googleapis.com/css2?family=Roboto&display=swap" rel="stylesheet">
	<link rel="preconnect" href="https://fonts.gstatic.com">
<link href="https://fonts.googleapis.com/css2?family=Lato:wght@700&family=Roboto&display=swap" rel="stylesheet">
</head>
<body>


	<!-- header -->
	<header>
		<div class="head">
			<a href="<?php echo base_url('sample/index') ?>">Web Application</a>
		</div>
		<div class="log">
			<!-- <ul>
				<li><a id="login" title="Login">Login</a></li>
				<li><a id="signup" title="Signup">Signup</a></li>
			</ul> -->
		</div>
	</header>
<!-- end of header -->

<!-- section -->

	<div class="sec">
		
	</div>

<!-- end of section -->


<!-- form -->
	<div class="form">
		<div class="form_content">
			<h4>Update Data</h4>
			<form action="<?php echo base_url('sample/update') ?>" method="POST" autocomplete="off">
				<input id="id" type="hidden" name="id" placeholder="First Name"  value="<?php echo $tbl_data->id; ?>">
				<label for="fname">
					First Name:
				</label>
				<input id="fname" type="text" name="fname" placeholder="First Name"  value="<?php echo $tbl_data->fname; ?>" required>
				<label for="fname">
					Last Name:
				</label>
				<input id="lname" type="text" name="lname" placeholder="Last Name"  value="<?php echo $tbl_data->lname; ?>" required>
				<label for="fname">
					Email:
				</label>
				<input id="user" type="text" name="email" placeholder="Email"  value="<?php echo $tbl_data->email ?>" required>
				<ul>
					<li><input type="submit" name="update" value="Update" placeholder="" id="update"></li>
					<!-- <li><button id="back" onclick="back();">Back</button></li> -->
				</ul>
			</form>

		</div>
	</div>
	<!-- end of form -->

	<script type="text/javascript">
		
		function back(){
			alert("back");
		}


	</script>

	
</body>
</html>