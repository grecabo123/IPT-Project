<?php  

defined('BASEPATH') OR exit('No direct script access allowed');



/**
 * summary
 */
class Admin extends CI_Controller
{
    /**
     * summary
     */
    function __construct()
    {
        parent:: __construct();
        // own constructor code
		$this->load->model('db_data','d');
    }


    function admin(){
    	$this->load->view('admin/data.php');
    }

    
}


?>