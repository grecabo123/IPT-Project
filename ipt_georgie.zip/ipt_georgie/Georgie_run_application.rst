Step 1: You kmust upload the database before you runnning this web application beacause it contains some data from the database
Step 2: The database name which is "ipt_project" then the table name which is "account"


Web application link: http://localhost/ipt_georgie/sample